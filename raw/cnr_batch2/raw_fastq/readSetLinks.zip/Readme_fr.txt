Pour t�l�charger les fichiers de lecture pr�alablement s�lectionn�s dans l'application MPS de Nanuq, il faut suivre les �tapes suivantes :

1) D�archiver le fichier zip dans le r�pertoire o� les donn�es doivent �tre enregistr�es.

2) Ex�cuter le fichier de commande run_wget.sh pour t�l�charger les donn�es � partir de l'application MPS de Nanuq.
   Il vous sera peut-�tre n�cessaire de modifier les droits d'ex�cution.

3) Un nom d'usager et un mot de passe vous seront demand�s. Veuillez utiliser ceux fournis pour vous connecter � Nanuq.
   Le t�l�chargement commencera apr�s validation de vos identifiants de connexion.

4) Pour chaque fichier t�l�charg� un fichier md5 a �t� aussi t�l�charg�, pour valider les fichiers t�l�charg�s vous devez ex�cuter la commande suivante:
   md5sum -c *.md5. 
Contacter l'�quipe Nanuq en cas de probl�me avec le processus de t�l�chargement.
   
�quipe Nanuq 
